var mapboxAccessToken = 'pk.eyJ1IjoibGJlbmN6IiwiYSI6ImNsZGVuZDJudzBhdDgzb3FiY3N6eDBhaXgifQ.78HzulaJ8rRPgX0bxND9zg';
var mapboxStyleId = 'lbencz/cmknfjwyb003a01s6hae3d5es';

var map;
var scroller;
var markers = []; 
var overlays = []; 
var extraMarkersGroup;

// CACHE DE VETORES (Mantido para performance)
var vectorCache = {}; 

var showLayers = true; 
var currentChapterIndex = -1; 

function initStoryMap(data) {
    var isMobile = (window.innerWidth <= 768) || (L.Browser.mobile);

    var startLat = -25.4284;
    var startLon = -49.2733;
    var startZoom = 12;

    if (data.length > 0) {
        startLat = parseFloat(data[0].Latitude.replace(',', '.'));
        startLon = parseFloat(data[0].Longitude.replace(',', '.'));
        startZoom = parseFloat(data[0].Zoom) || 12;
    }

    // --- 1. PRÉ-CARREGAMENTO (Performance) ---
    data.forEach(row => {
        if (row.Overlay) {
            var inputs = row.Overlay.split(',');
            inputs.forEach(input => {
                var url = input.trim();
                var lower = url.toLowerCase();
                if ((lower.endsWith('.geojson') || lower.endsWith('.json')) && !vectorCache[url]) {
                    vectorCache[url] = fetch(url)
                        .then(res => res.json())
                        .catch(err => console.error("Falha no pré-load:", url));
                }
            });
        }
    });

    // --- MAPA ---
    map = L.map('map', {
        center: [startLat, startLon], 
        zoom: startZoom,
        zoomControl: false,     
        
        // Bloqueios iniciais
        scrollWheelZoom: false, 
        
        // Mobile: Travado inicialmente
        // Desktop: Destravado
        dragging: !isMobile,
        touchZoom: !isMobile,
        doubleClickZoom: !isMobile,
        
        tap: true 
    });

    if (isMobile) {
        map.dragging.disable();
        map.touchZoom.disable();
        map.doubleClickZoom.disable();
        map.scrollWheelZoom.disable();
        map.boxZoom.disable();
        map.keyboard.disable();
    }

    L.tileLayer(`https://api.mapbox.com/styles/v1/${mapboxStyleId}/tiles/256/{z}/{x}/{y}@2x?access_token=${mapboxAccessToken}`, {
        attribution: 'Lilian Bencz | Mapbox', maxZoom: 18, tileSize: 512, zoomOffset: -1
    }).addTo(map);

    extraMarkersGroup = L.layerGroup().addTo(map);

    L.control.zoom({ position: 'topright' }).addTo(map);

    setTimeout(function(){ map.invalidateSize(); }, 500);

    // --- BOTÕES FLUTUANTES ---
    var controlsDiv = document.createElement('div');
    controlsDiv.id = 'floating-controls';
    document.body.appendChild(controlsDiv);

    var layerBtn = document.createElement('button');
    layerBtn.className = 'btn-floating btn-layer'; 
    layerBtn.innerHTML = 'Layers';
    
    layerBtn.onclick = function() {
        showLayers = !showLayers;
        if (showLayers) {
            layerBtn.classList.remove('layers-off');
            layerBtn.innerHTML = 'Layers';
        } else {
            layerBtn.classList.add('layers-off');
            layerBtn.innerHTML = 'Ocultar Layers';
        }
        
        if (currentChapterIndex >= 0 && overlays[currentChapterIndex]) {
            var currentLayers = overlays[currentChapterIndex]; 
            currentLayers.forEach(function(layerObj) {
                if (layerObj && layerObj.layerInstance) {
                    if (showLayers) {
                        if (!map.hasLayer(layerObj.layerInstance)) map.addLayer(layerObj.layerInstance);
                    } else {
                        if (map.hasLayer(layerObj.layerInstance)) map.removeLayer(layerObj.layerInstance);
                    }
                }
            });
        }
    };
    controlsDiv.appendChild(layerBtn);

    var toggleBtn = document.getElementById('toggle-mode');
    if (toggleBtn) {
        toggleBtn.classList.add('btn-floating');
        controlsDiv.appendChild(toggleBtn);
    }

    var storyContainer = document.getElementById('story');
    var chapters = [];

    // HEADER
    var headerId = 'header-step';
    var headerDiv = document.createElement('div');
    headerDiv.setAttribute('id', headerId);
    headerDiv.classList.add('step'); 
    
    headerDiv.innerHTML = `
        <video id="video-piece-title-video" preload="auto" playsinline="" autoplay="" muted="" loop="" poster="">
            <source src="media/intropoty.mp4" type="video/mp4">
        </video>
        <div class="header-content">
            <img src="media/poty.png" alt="Poty Lazzarotto" class="header-image">
            <h1> </h1>
            <p>Em uma jornada pela história de Curitiba, exploraremos como o saneamento e a mobilidade moldaram o crescimento da cidade ao longo do tempo. Viajaremos através dos anos, explorando mapas históricos e descobrindo como o artista Poty Lazzarotto retratou essa narrativa em suas obras, que permeiam toda a cidade.</p>
        </div>
        <div id="scroll-overlay"> Continue ↓ </div>
    `;
    storyContainer.insertBefore(headerDiv, storyContainer.firstChild);

    chapters.push({ id: headerId, index: -1, isHeader: true, extraMarkersData: [] });

    if (typeof araucIcon === 'undefined') console.warn("Aviso: Ícones globais não encontrados.");

    // LOOP DADOS
    data.forEach((row, i) => {
        if (!row.Latitude || !row.Chapter) return;

        var lat = parseFloat(row.Latitude.replace(',', '.'));
        var lon = parseFloat(row.Longitude.replace(',', '.'));
        var zoomLevel = parseFloat(row.Zoom) || 12;
        var chapterNum = i + 1;
        
        var customIcon;
        switch (chapterNum) {
            case 1: customIcon = araucIcon; break;
            case 2: customIcon = tropeirosIcon; break;
            case 3: customIcon = chafarizIcon; break;
            case 4: customIcon = tuboIcon; break;
            case 5: customIcon = jacareIcon; break;
            default: customIcon = (typeof arauc2Icon !== 'undefined') ? arauc2Icon : araucIcon;
        }

        var marker = L.marker([lat, lon], { icon: customIcon, opacity: 0 });
        marker.addTo(map); 
        markers.push(marker);

        // EXTRAS
        var chapterExtras = [];
        if (row['Extra Markers'] && row['Extra Markers'].trim() !== "") {
            var rawExtras = row['Extra Markers'].split(';'); 
            rawExtras.forEach(function(item) {
                var parts = item.split('|'); 
                if (parts.length >= 3) {
                    var exLat = parseFloat(parts[0].trim().replace(',', '.'));
                    var exLon = parseFloat(parts[1].trim().replace(',', '.'));
                    var exText = parts[2].trim();
                    var iconToUse = (typeof pinhaoIcon !== 'undefined') ? pinhaoIcon : customIcon;

                    if (parts.length >= 4) {
                        var iconVarName = parts[3].trim();
                        // Verifica se o nome digitado na planilha corresponde a uma variável global existente
                        if (iconVarName !== "" && typeof window[iconVarName] !== 'undefined') {
                            iconToUse = window[iconVarName];
                        } else if (iconVarName !== "") {
                            console.warn("Ícone extra não encontrado no arquivo de marcadores: " + iconVarName);
                        }
                    }
                    
                    var extraMarker = L.marker([exLat, exLon], { icon: iconToUse, opacity: 1 });
                    extraMarker.bindPopup(exText);
                    chapterExtras.push(extraMarker);
                }
            });
        }
        
        // OVERLAYS (Tiles e Vetores Otimizados)
        var chapterLayers = []; 
        if (row.Overlay && row.Overlay.trim() !== "") {
            var inputs = row.Overlay.split(',');
            var opacities = [];
            if (row['Overlay Transparency']) {
                opacities = row['Overlay Transparency'].toString().split(',');
            }
            inputs.forEach(function(rawInput, idx) {
                var input = rawInput.trim();
                if (input === "") return;
                var currentOpacity = 0.8; 
                if (opacities[idx]) currentOpacity = parseFloat(opacities[idx].trim()) || 0.8;
                else if (opacities.length > 0) currentOpacity = parseFloat(opacities[0].trim()) || 0.8;

                var layerObj = null;
                var inputLower = input.toLowerCase(); 

                if (inputLower.endsWith('.geojson') || inputLower.endsWith('.json')) {
                    // GeoJSON (Usa cache)
                    layerObj = { type: 'geojson', url: input, layerInstance: null, opacity: currentOpacity };
                } else {
                    // WMS ou Tiles
                    var layerName = input;
                    var wmsUrl = 'https://idea.ufpr.br/geoserver/ows';
                    if (!layerName.includes(':') && !layerName.startsWith('http')) layerName = 'geonode:' + layerName;
                    
                    if (layerName.startsWith('http')) {
                        layerObj = { type: 'image', url: input, layerInstance: null };
                    } else {
                        var wmsLayer = L.tileLayer.wms(wmsUrl, {
                            layers: layerName, 
                            format: 'image/png', 
                            transparent: true,
                            opacity: currentOpacity,
                            noWrap: true, // Evita repetição
                            tms: false,
                            updateWhenIdle: true, // Otimiza mobile
                            keepBuffer: 2
                        });
                        layerObj = { type: 'wms', layerInstance: wmsLayer };
                    }
                }
                if (layerObj) chapterLayers.push(layerObj);
            });
        }
        overlays.push(chapterLayers); 

        // HTML
        var chapterId = 'chapter-' + i;
        var container = document.createElement('div');
        container.setAttribute('id', chapterId);
        container.classList.add('step', 'centered');

        var content = document.createElement('div');
        content.classList.add('light');
        if (row.Chapter) content.innerHTML += `<h3>${row.Chapter}</h3>`;
        
        if (row['Media Link']) {
            var m = row['Media Link'].trim();
            var mLower = m.toLowerCase(); 
            if (mLower.includes('youtube') || mLower.includes('youtu.be')) {
                var videoId = m.split('v=')[1];
                if(videoId && videoId.indexOf('&') != -1) videoId = videoId.split('&')[0];
                var embedUrl = "https://www.youtube.com/embed/" + videoId;
                content.innerHTML += `<div class="video-container"><iframe src="${embedUrl}" frameborder="0" allowfullscreen></iframe></div>`;
            } else if (mLower.endsWith('.mp3') || mLower.endsWith('.wav') || mLower.endsWith('.ogg')) {
                content.innerHTML += `<div style="margin: 20px 0;"><audio controls style="width: 100%;"><source src="${m}" type="audio/mpeg"></audio></div>`;
            } else if (mLower.endsWith('.mp4') || mLower.endsWith('.webm') || mLower.endsWith('.mov')) {
                 content.innerHTML += `<div class="video-container" style="padding-bottom: 0; height: auto;"><video controls style="width: 100%; border-radius: 5px;"><source src="${m}" type="video/mp4"></video></div>`;
            } else {
                content.innerHTML += `<img src="${m}" alt="${row.Chapter}">`;
            }
            if (row['Media Credit']) content.innerHTML += `<p class="caption">${row['Media Credit']}</p>`;
        }
        if (row.Description) content.innerHTML += `<p>${row.Description}</p>`;
        container.appendChild(content);
        storyContainer.appendChild(container);

        chapters.push({ 
            id: chapterId, index: i, location: [lat, lon], zoom: zoomLevel, isHeader: false, extraMarkersData: chapterExtras 
        });
    });

    // RODAPÉ
    var footerDiv = document.createElement('div');
    footerDiv.setAttribute('id', 'footer');
    footerDiv.innerHTML = `<button class="btn-restart" onclick="window.scrollTo({top: 0, behavior: 'smooth'})">⬆ Voltar ao Início</button>`;
    storyContainer.appendChild(footerDiv);

    // LIGHTBOX
    $('body').append('<div id="lightbox"><span id="lightbox-close">&times;</span><div id="lightbox-content"></div></div>');
    $(document).on('click', '.step img', function(e) {
        if ($('#story').hasClass('story-hidden')) { e.preventDefault(); e.stopPropagation(); return; }
        $('#lightbox-content').html('<img src="' + $(this).attr('src') + '">');
        $('#lightbox').addClass('active');
    });
    $(document).on('click', '.step video', function(e) {
        if ($('#story').hasClass('story-hidden')) { e.preventDefault(); e.stopPropagation(); return; }
        $('#lightbox-content').html(`<video controls autoplay style="max-width: 100%; max-height: 90vh;"><source src="${$(this).find('source').attr('src')}" type="video/mp4"></video>`);
        $('#lightbox').addClass('active');
    });
    $(document).on('click', '#lightbox, #lightbox-close', function(e) {
        if (e.target.id === 'lightbox' || e.target.id === 'lightbox-close') {
            $('#lightbox').removeClass('active');
            setTimeout(function(){ $('#lightbox-content').empty(); }, 300); 
        }
    });

    $('#loader').fadeOut();

    scroller = scrollama();

    scroller
        .setup({ step: '.step', offset: 0.5, progress: true })
        .onStepEnter(response => {
            var chapter = chapters.find(c => c.id === response.element.id);
            if (!chapter) return; 

            $('.step').removeClass('active');
            response.element.classList.add('active');

            var currentIsMobile = (window.innerWidth <= 768) || (L.Browser.mobile);

            if (chapter.isHeader) {
                $('#floating-controls').addClass('buttons-hidden'); 
                currentChapterIndex = -1; 
                markers.forEach(m => m.setOpacity(0));
                extraMarkersGroup.clearLayers(); 
                overlays.forEach(chapterLayers => {
                    chapterLayers.forEach(obj => {
                        if (obj && obj.layerInstance && map.hasLayer(obj.layerInstance)) map.removeLayer(obj.layerInstance);
                    });
                });

            } else {
                $('#floating-controls').removeClass('buttons-hidden'); 

                if (currentIsMobile) {
                    map.setView(chapter.location, chapter.zoom);
                } else {
                    map.flyTo(chapter.location, chapter.zoom, { 
                        animate: true, duration: 3.5, easeLinearity: 0.25 
                    });
                }

                var idx = chapter.index;
                currentChapterIndex = idx; 

                markers.forEach((m, i) => {
                    if (i === idx) { m.setOpacity(1); m.getElement().style.pointerEvents = 'auto'; } 
                    else { m.setOpacity(0); if(m.getElement()) m.getElement().style.pointerEvents = 'none'; }
                });

                extraMarkersGroup.clearLayers(); 
                if (chapter.extraMarkersData && chapter.extraMarkersData.length > 0) {
                    chapter.extraMarkersData.forEach(function(m) {
                        extraMarkersGroup.addLayer(m); 
                    });
                }

                overlays.forEach((chapterLayers, i) => {
                    if (i !== idx) {
                        chapterLayers.forEach(obj => {
                            if (obj && obj.layerInstance && map.hasLayer(obj.layerInstance)) map.removeLayer(obj.layerInstance);
                        });
                    }
                });
                
                var currentLayers = overlays[idx];
                if (currentLayers && currentLayers.length > 0) {
                    currentLayers.forEach(function(currentOverlay) {
                        var prepareLayer = function() {
                            if (currentOverlay.type === 'wms') {} 
                            else if (currentOverlay.type === 'image') {
                                if(!currentOverlay.layerInstance) {
                                    currentOverlay.layerInstance = L.tileLayer(currentOverlay.url, { noWrap: true, tms: false });
                                }
                            }
                            else if (currentOverlay.type === 'geojson') {
                                if (!currentOverlay.layerInstance) {
                                    if (vectorCache[currentOverlay.url]) {
                                        vectorCache[currentOverlay.url].then(data => {
                                            var style = { color: '#DC4D01', weight: 2, opacity: 1, fillOpacity: (currentOverlay.opacity || 0.5) };
                                            currentOverlay.layerInstance = L.geoJSON(data, { style: style });
                                            if(currentChapterIndex === idx && showLayers) currentOverlay.layerInstance.addTo(map);
                                        });
                                    } else {
                                        fetch(currentOverlay.url)
                                            .then(res => res.json())
                                            .then(data => {
                                                var style = { color: '#DC4D01', weight: 2, opacity: 1, fillOpacity: (currentOverlay.opacity || 0.5) };
                                                currentOverlay.layerInstance = L.geoJSON(data, { style: style });
                                                if(currentChapterIndex === idx && showLayers) currentOverlay.layerInstance.addTo(map);
                                            })
                                            .catch(err => console.error("Erro GeoJSON:", err));
                                    }
                                    return false; 
                                }
                            }
                            return true; 
                        };
                        var ready = prepareLayer();
                        if (ready && showLayers && currentOverlay.layerInstance) {
                            if (!map.hasLayer(currentOverlay.layerInstance)) currentOverlay.layerInstance.addTo(map);
                        }
                    });
                }
            }
        })
        .onStepExit(response => {
            var chapter = chapters.find(c => c.id === response.element.id);
            if (chapter) response.element.classList.remove('active');
        });

    window.addEventListener('resize', scroller.resize);

    $(document).off('click', '#toggle-mode');
    
    // --- LÓGICA DO BOTÃO VER MAPA (ATUALIZADA) ---
    $(document).on('click', '#toggle-mode', function(e) {
        e.preventDefault(); 
        var storyDiv = $('#story');
        var btn = $(this);
        var currentIsMobile = (window.innerWidth <= 768) || (L.Browser.mobile);
        
        // Alterna classe que agora usa visibility: hidden (mantém scroll)
        storyDiv.toggleClass('story-hidden');
        var isHidden = storyDiv.hasClass('story-hidden');

        if (isHidden) {
            // MODO MAPA LIVRE
            btn.html('Ver História');
            
            // Ativa Arrastar (Pan)
            map.dragging.enable();
            
            // Zoom livre SÓ no desktop
            if (!currentIsMobile) {
                map.touchZoom.enable();
                map.doubleClickZoom.enable();
                map.scrollWheelZoom.enable();
            } else {
                // Mobile: Zoom de pinça TRAVADO, só botões
                map.touchZoom.disable();
                map.doubleClickZoom.disable();
            }
            if (map.tap) map.tap.enable();
            
            $('#map').css('cursor', 'grab');

        } else {
            // MODO LEITURA
            btn.html('Ver Mapa');
            
            map.scrollWheelZoom.disable();

            if (currentIsMobile) {
                map.dragging.disable();
                map.touchZoom.disable();
                map.doubleClickZoom.disable();
            }
            // Não precisamos mais restaurar scroll manual, o CSS cuida disso
            scroller.resize();
        }
    });
}

// Inicialização Ajax
$(document).ready(function() {
    if (typeof googleDocURL !== 'undefined' && googleDocURL && typeof googleApiKey !== 'undefined' && googleApiKey) {
        var spreadsheetId = googleDocURL.split('/d/')[1].split('/')[0];
        $.ajax({
            url: `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Chapters?key=${googleApiKey}`,
            dataType: 'json',
            success: function(response) { initStoryMap(parseGoogleSheetData(response.values)); },
            error: function(e) { console.error("Erro API:", e); $('#loader').html("Erro ao carregar."); }
        });
    } else { alert('Configure google-doc-url.js'); }
});

function parseGoogleSheetData(rows) {
    if (!rows || rows.length === 0) return [];
    var headers = rows[0];
    var data = [];
    for (var i = 1; i < rows.length; i++) {
        var row = rows[i]; var obj = {};
        for (var j = 0; j < headers.length; j++) { obj[headers[j]] = row[j] ? row[j] : ""; }
        data.push(obj);
    }
    return data;
}