// paste in your published Google Sheets URL from the browser address bar
var googleDocURL = 'https://docs.google.com/spreadsheets/d/1cxh7RxJISlvMxypemH3PM1sY5Ve-P_AMwdmc-YvCJwE/edit?usp=sharing';

// insert your own Google Sheets API key from https://console.developers.google.com
var googleApiKey = 'AIzaSyAtJarj0kmrj8KxD8kHrTjwhsEMiCTwJ94';
